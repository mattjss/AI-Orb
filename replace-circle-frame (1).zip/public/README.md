# Static assets

- **orb.webm** — Add your Figma orb video here (export from Figma as WebM). The search bar will use it for the 32×32 orb. If the file is missing, a CSS gradient fallback (iridescent style) is shown.
